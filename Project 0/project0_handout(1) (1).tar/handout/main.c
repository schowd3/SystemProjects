#include <stdio.h>
#include "scheduler.h"

int main() {
  scheduler_generate("doasndoasdoasnda");
  printf(...);

}
