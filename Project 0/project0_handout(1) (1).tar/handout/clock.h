/* Do Not Modify This File */

#ifndef CLOCK_H
#define CLOCK_H

void clock_init(int time_start);
int clock_get_time();
void clock_advance_time();

#endif /* CLOCK_H */
